/** Global variables. */
var rowCount = 6;
var colCount = 7;

/**
	Assembles the 6x7 board.
 */
function createBoard() {
	var tbl = "<table>";

	for (var ri = 0; ri < rowCount; ri += 1) {
		tbl += "<tr>";
		for (var ci = 0; ci < colCount; ci += 1) {
			tbl += "<td id =" + (ri + "" + ci) + ">" + ri + "x" + ci + "</td>";
		}
		tbl += "</tr>";
	}
document.getElementById("container").innerHTML = tbl;
}

function resetBoard() {
	yellowSpots.length = 0;
	redSpots.length = 0;
	player = true;
	person = "";
	rCount = 0;
	yCount = 0;
	createBoard();
}

/** Returns the number of rows of the board.*/
function getRowNum() {
	return rowCount;
}

/** Returns the number of columns of the board. */
function getColNum() {
	return colCount;
}