/** Tests to see if at least 4 numbers are consecutive or not. */

/*console.log('Horizontal Test: ');
console.log(isConsecutive([22,23,24,25])); // true
console.log(isConsecutive([1,2,3,4])); // true
console.log(isConsecutive([17,23,24,25])); // false
console.log(isConsecutive([0,65, 7, 2, 3, 4, 99, 100, 1, 6, 7, 8, 9])); // true
console.log(isConsecutive([0,0,1])); // false.
console.log(isConsecutive([0,0,1,2,2, 44, 54, 2, 1])); // false.
console.log(isConsecutive([22,23,24,0])); // false
console.log(isConsecutive([22,23])); // false
console.log(''); */

/** Test if at least 4 numbers are "vertically aligned" or not.*/

/*console.log('Vertical Test: ');
console.log(consecutiveByTen([1,2,3,4])); // false
console.log(consecutiveByTen([1,20,30,40])); // false
console.log(consecutiveByTen([1,20,30,40,50])); // true
console.log(consecutiveByTen([1,20,30,3,40,99,50])); // true
console.log(consecutiveByTen([1,20,30,3,40,99,230])); // false
console.log(consecutiveByTen([00, 10, 20, 30])); // true 
console.log(''); */

/** Tests to see if diagonally downward right or not.*/

/*console.log('Downward Right Diagonal Test: ');
console.log(checkLeftDiag(['00', '11', '22', '33', '44'])); // true
console.log(checkLeftDiag(['10', '21', '32', '43'])); // true
console.log(checkLeftDiag(['10'])); // false
console.log(checkLeftDiag(['12', '13', '14', '23', '34', '45'])); // true
console.log(checkLeftDiag(['50','51','33', '14','06','03','12','14', '26', '25', '36'])); // true
console.log(checkLeftDiag(['50','56', '43', '51'])); // false
console.log(checkLeftDiag(['50','56'])); // false
console.log(checkLeftDiag([])); // false
console.log(checkLeftDiag(['00','11','22','44'])); // false
console.log(checkLeftDiag(['00','11','33','44'])); // false
console.log(checkLeftDiag(['20','42','53','44'])); // false 
console.log(checkLeftDiag(['20', '31', '41', '42', '51', '52', '53'])); // true.
console.log(checkLeftDiag(['10', '21', '31', '32', '41', '43', '51', '52'])); //true.
console.log(checkLeftDiag(['10','21','31','32','41','43','51'])); //true. 
console.log(''); */

/** Tests to see if diagonally upward right or not. */

/*console.log('Upward Right Diagonal Test: ');
console.log(checkRightDiag(['06','15','24','33'])); // true.
console.log(checkRightDiag(['24','33','42','51'])); // true.
console.log(checkRightDiag(['06','24','33','42'])); //false.
console.log(checkRightDiag(['26','35','44','53'])); // true.
console.log(checkRightDiag(['04', '22','31','40'])); //false.
console.log(checkRightDiag(['04','13','56','22','31'])); //true.
console.log(checkRightDiag(['00','23','26','34','35', '45','44','53'])); // false.
*/