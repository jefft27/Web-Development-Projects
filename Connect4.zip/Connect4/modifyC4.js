/* Creates the gameboard and displays it on the browser screen. */
createBoard();

/** Global Variable.*/
var player = true;
var playAgain = true;
var person = "";
var redSpots = [];
var yellowSpots = [];
var rCount = 0;
var yCount = 0;

/** Changes the mouse cursor to a pointer.*/
function Cursor(id) {
	id.style.cursor = 'pointer';
}

/** Places either a red or yellow piece in the
    appropriate slot. Player initially starts out
	red and then switches to yellow.*/
function placePiece(elem){
	if (playAgain) {
		var emptySpot = getEmptySpot(elem.id);
		if (player) {
			document.getElementById(emptySpot).style.backgroundColor = "red";
			redSpots[rCount] = emptySpot;
			rCount += 1;
			player = false;
		} else {
			document.getElementById(emptySpot).style.backgroundColor = "yellow";
			yellowSpots[yCount] = emptySpot;
			yCount += 1;
			player = true;
		}
		
		if(isWin(player)) {
			if (!player) {
				person = "red";
			} else {
				person = "yellow";
			}
			window.alert(person + " has won the game!");
			var prompt = confirm('Play again?');
			if (prompt) {
				resetBoard();
			} else {
				playAgain = false;
			} 
		}
	} else {
		var reset = confirm('Do you want to play again?');
		if (reset) {
			resetBoard();
			playAgain = true;
		}
	}
}

/** Checks to see if there are 4 pieces of the
    same color horizontally, vertically, or
    diagonally.*/
function isWin(player) {
	var arr = [];
	
	if (!player) { //red
		arr = redSpots;
	} else { //yellow.
		arr = yellowSpots;
	}
	arr.sort();

	if (isWinHorizontal(player, arr) || isWinDiagRight(player, arr)
	    || isWinDiagLeft(player, arr)|| isWinVertically(player, arr)) {
		return true;
	}
	return false;	
}

/** Returns true if there are 4 pieces
	of the same color horizontally, otherwise, false.*/
function isWinHorizontal(player, arr) {
	return isConsecutive(arr);
}

/** Returns true if at least 4 numbers are in
	consecutive order, false otherwise. */
function isConsecutive(arr) {
	var counter = 0;
	var num1 = parseInt(arr[0]);
	for (var i = 1; i < arr.length; i += 1) {
		var num2 = parseInt(arr[i]);
		if (num1 == num2 - 1) {
			counter += 1;
			if (counter >= 3){
				return true;
			}
		} else {
			counter = 0;
		}
		num1 = num2;
	}
	return false; 
}

/** Returns true if there are 4 piece of the
    same color diagonally going right, false otherwise.*/
function isWinDiagRight(player, arr) {
	return checkRightDiag(arr);
}

/** Checks if the array ARR contains pieces 
	of the same color that are in a diagonal.*/
function checkRightDiag(arr) {
	var pos = 0;
	var rowPos = 1;
	var count = 1;
	var colPos = 10;
	
	for (var i = 0; i < arr.length; i += 1) {
		var num = parseInt(arr[i]);
		while(pos < 3) {
			var next = parseInt((num + colPos) - rowPos); 
			if (arr.indexOf((next.toString())) > -1) {
				count += 1;
			}
			pos += 1;
			num = next;
		}
		if (count >= 4) {
			return true;
		}
		pos = 1;
		colPos = 10;
		count = 1;
	}
	return false;
}

/** Returns true if there are 4 piece of the same
    color diagonally going left, false otherwise.*/
function isWinDiagLeft(player, arr) {
	return checkLeftDiag(arr);
}

/** Checks if the array ARR contains pieces 
	of the same color that are in a diagonal.*/
function checkLeftDiag(arr) {
	var count = 1;
	var incr = 11;
	var pos = 0;
	
	for (var i = 0; i < arr.length; i += 1) {
		var num = parseInt(arr[i]);
		while (pos < 3) {
			var next = num + incr;
			if (arr.indexOf((next.toString())) > -1) {
				count += 1;
			}
			pos += 1;
			num = num + incr;
		}
		if (count >= 4) {
			return true;
		}
		count = 1;
		pos = 1; 
	}
	return false;
}

/** Returns true if there are 4 pieces of the same
    color vertically, false otherwise.*/
function isWinVertically(player, arr) {
	return consecutiveByTen(arr);
}
	
/** Returns true if there are 4 pieces
	of the same color in a row, otherwise false.*/
function consecutiveByTen(arr){
	var count = 1;
	var incr = 10;
	for (var i = 0; i < arr.length; i += 1) {
		var curr = parseInt(arr[i]);
		for (var j = i + 1; j < arr.length; j += 1) {
			var next = parseInt(arr[j]);
			if (next == (curr + incr)) {
				count += 1;
				incr += 10;
			}
			if (count >= 4) {
				return true;
			}
		}
		count = 1;
		incr = 10;
	}
	return false;
}

/** Returns the id number of the spot that is empty.*/
function getEmptySpot(number) {
	count = getRowNum() - 1;
	var idNum = count.toString() + "" + number.toString();

	while (count >= 0) {
		if (document.getElementById(idNum).style.backgroundColor == "") {
			return idNum;
		}
		count -= 1;
		idNum = count.toString() + "" + number.toString();
	}
	return idNum;
}