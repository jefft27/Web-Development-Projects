/** 
The HashMap Class.
@author: Jeffrey Tan
*/
function HashMap(obj) {
	// The number of items in the hashmap.
	this.length = 0;
	// The associative array.
	this.items = {};

	/** Assigns KEY to a specific VALUE. There can be
	   only one unique KEY that maps to a specific VALUE.*/
	this.put = function(key, value) {
		this.items[key] = value;
		this.length += 1;
	}
	
	/** Checks to see if items has the specified key. Returns 
	true if it does, false otherwise.*/
	this.containsKey = function(key){
		if(key in this.items) {
			return true;
		}
		return false;
	}
	
	/** Returns the VALUE of the KEY if found in ITEMS, else
       it returns null.*/
	this.get = function(key) {
		if(key in this.items) {
			return this.items[key];
		}
		return null;
	}
	
	/** 
	Returns true if ITEMS contains no elements inside of it,
	otherwise false.
	*/
	this.isEmpty = function() {
		if(this.length > 0) {
			return true;
		}
		return false;
	}
	
	/** Removes the mapping for the specified key 
	   from this map if present. */
	this.remove = function(key) {
		if (key in this.items) {
			delete this.items[key];
			this.length -= 1;
		}
	}
	
	/** Returns true if this map maps one or more keys
	   to a specified value.*/
	this.containsValue = function(value) {
		for (var k in this.items) {
			if(this.items[k] == value) {
				return true;
			}
		}
		return false;
	}
	
	/** Removes all the mappings from this map. */
	this.clear = function () {
		for (var k in this.items) {
			delete this.items[k];
		}
		this.length = 0;
	}
}