/** 
Where all the operations are done.
@author: Jeffrey Tan
*/

/** Global Variables.*/
var mode = false;
var mapEncoder = new HashMap();
var mapDecoder = new HashMap();
var map = new Mapper();

/** Assigns the key - value pairs to MapEncoder and MapDecoder.*/
populateMap();

/** When the input box is focused then the initial 
	text will be replaced with nothing.*/
function clearBox() {
	document.getElementById("box").value = "";
}

/** Assigns each character to a certain
	morse code symbol and also does the reverse.*/
function populateMap() {
	var len = map.chars.length;
	var count = 0;
	while (count < len) {
		mapEncoder.put(map.chars[count], map.symbols[count]);
		mapDecoder.put(map.symbols[count], map.chars[count]);
		count += 1;
	}
}

/** Encodes or decodes the text. */
function changeText(id) { 
	var sentence = "";
	if (!mode) { // encoding text.
		for (var i = 0; i < id.length; i += 1) {
			if (id[i] == " ") {
				id = id.substring(0, i) + "_" + id.substring(i + 1);
				sentence += id[i] + " ";
			} else {
				var ltr = mapEncoder.get(id[i].toLowerCase());
				if (ltr == null) {
					window.alert("You have an invalid character: " + id[i]);
					return "Error";
				} else {
					sentence += ltr + " ";
				}
			}
		}
		console.log('encoded sentence is: ' + sentence);
	} else { //decoding text.
		var arr = id.trim().split(/\s+/);
		if(arr.length == 0) {
			return null;
		}
		for (var i = 0; i < arr.length; i += 1) {
			if (arr[i] != "_") {
				sentence += mapDecoder.get(arr[i]);
			} else {
				sentence += " ";
			}
		}
	}
	return sentence;
}

/** Changes the value of the submit button
   depending on whether the mode is true or false.*/
function changeValue() {
	var id = document.getElementById("box").value;
	var text = changeText(id);
	if (!mode) {
		if (text == "Error") {
			document.getElementById("box").value = "Please type again";
		} else {
			document.getElementById("btn").value = "Decode";
			document.getElementById("box").value = text;
			mode = true;
		}
	} else {
		if (text == "null") {
			text = "Type here!";
		}
		document.getElementById("btn").value = "Encode";
		document.getElementById("box").value = text;
		mode = false;
	}
}