import os
import jinja2
import webapp2
from google.appengine.ext import db
from Handler import Handler
from DB import blog_key

class WikiplHandler(Handler):

    def get(self, id):
        key = db.Key.from_path('Post', int(id), parent = blog_key())
        post = db.get(key)

        if not post:
            self.error(404)
        else:
            self.render('wikipermalink.html', post = post)