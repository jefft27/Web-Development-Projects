import os
import re
import jinja2
import webapp2

from Handler import Handler
from DB import Post

class NewPostHandler(Handler):

    def render_page(self, subj = "", content = "", error = ""):
        return self.render('newpost.html', subj = subj, content = content, error = error)

    def get(self):
        self.render_page()

    def post(self):
        self.title = self.request.get('subj')
        self.content = self.request.get('content')
        self.category = self.request.get_all('categories')[0]
        self.creator = self.request.cookies.get('mycookie')
        self.error = self.request.get('err')

        if (self.title and self.content and self.category != "Categories"):
            post_obj = Post.create_post(self.title, self.content, self.category, self.creator)
            post_obj.put()
            self.redirect('/wiki/%s' % str(post_obj.key().id()))
        else:
        	self.error = "Please make sure all the fields are filled in!"
        	self.render_page(self.title, self.content, self.error)