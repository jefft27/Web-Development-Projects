import os
import re
import jinja2
import webapp2
from Handler import Handler

class LogoutHandler(Handler):

    def get(self):
        self.response.delete_cookie('mycookie')
        self.redirect("/")