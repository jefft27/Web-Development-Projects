import os
import re
import jinja2
import webapp2

from Handler import Handler
from google.appengine.ext import db
from DB import Post

CACHE = {}
nlinks = 0
incr = 10

class WikiHandler(Handler):

    def run_query(self, update = False):
        key = 'top'
        if ((not (key in CACHE)) or update):
            CACHE[key] = db.GqlQuery("SELECT * FROM Post ORDER BY edited DESC")
        return list(CACHE[key])

    def render_page(self, user = "", query = list(), nothing = "", attr = "visible"):
        if (self.request.cookies.get('mycookie') == None):
            self.redirect('/?')
        else:
            self.render('wiki.html', user = user, query = query,
                        nothing = nothing, attr = attr)

    def get(self):
        self.user = self.request.cookies.get('mycookie')
        query = self.run_query()[0:incr]
        self.render_page(self.user, query)

    def post(self):
        self.user = self.request.cookies.get("mycookie")
        self.search_text = self.request.get('search').lower()

        if (self.search_text != ""):
            query = list()
            for q in self.run_query():
                if (self.search_text in (q.subject).lower()):
                    query.append(q)
            if (len(query) == 0):
                nothing = "There seems to be nothing here!"
            else:
                nothing = ""
            attr = "none"
            self.render_page(self.user, query, nothing, attr)
        else:
            if (self.request.get('next') == "next"):
                query = self.run_query()
                global nlinks
                nlinks += incr
                if (len(query[nlinks:nlinks + incr]) == 0):
                    self.render('nextPage.html', query = query[nlinks : nlinks + incr],
                                nothing = "There is nothing here!", attr = "none")
                else:
                    self.render('nextPage.html', query = query[nlinks : nlinks + incr],
                                nothing = "", attr = "visible")
            elif (self.request.get('back') == "back"):
                query = self.run_query()
                if ((nlinks - incr) >= 10):
                    global nlinks
                    nlinks -= incr
                    self.render('nextPage.html', query = query[nlinks: nlinks + incr],
                                nothing = "")
                else:
                    global nlinks
                    nlinks = 0
                    self.render_page(self.user, query[0:incr], "")