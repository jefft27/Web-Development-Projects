import os
import jinja2
import webapp2
#import hmac
from bcrypt_master import bcrypt

template_dir = os.path.join(os.path.dirname(__file__), 'templates')
jinja_env = jinja2.Environment(loader = jinja2.FileSystemLoader(template_dir))

salt = bcrypt.gensalt()

class Handler(webapp2.RequestHandler):
    
    # Outputs text onto the browser's screen.
    def write(self, *a, **kw):
        self.response.out.write(*a, **kw)

    def render_str(self, template, **params):
        t = jinja_env.get_template(template)
        return t.render(params)

    # Takes in TEMPLATE (html file name) and any other parameters to 
    # be added to the 
    def render(self, template, **kw):
        self.write(self.render_str(template, **kw))

    # Assigns the user(name) to a specific value (hashed password)
    # and sets the cookie.
    def set_secure_cookie(self, name):
        self.response.set_cookie('mycookie', str(name), path = '/')

    def hashpw(self, key):
        return bcrypt.hashpw(key, salt)

    def checkPHash(self, db_pw, pw):
        if (db_pw == bcrypt.hashpw(pw, db_pw)):
            return True
        return False

    # Grabs the hashed password that is stored in the cookie
    # and checks if the value exists and if the pw is the same
    # as the password entered.
    #def read_secure_cookie(self, name):
        #cookie_val = self.request.cookies.get(name)
        #return cookie_val and check_secure_val(cookie_val)
