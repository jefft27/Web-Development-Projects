import re
import random
import string
import hashlib
import hmac

#### String Validation ####
USER_RE = re.compile("^[a-zA-Z0-9_-]{3,20}$")
PASSWORD_RE = re.compile("^.{3,20}$")
EMAIL_RE = re.compile("^[\S]+@[\S]+\.[\S]+$")

def valid_name(username):
    return USER_RE.match(username)

def valid_password(passw):
    return PASSWORD_RE.match(passw)

def passwordMatch(pass1, pass2):
    if (pass1 == pass2):
        return True
    return False

#### password hashing ####
def make_salt():
    strg = ""
    count = 0
    while (count < 5):
        strg += random.choice(string.letters)
        count += 1
    return strg

def make_pw_hash(name, pw, salt = None):
    if not (salt):
    	salt = make_salt()
    h = hashlib.sha256(name + pw + salt)
    return '%s|%s' % (h.hexdigest(), salt)

def valid_pw(name, pw, h):
    salt = h.split(',')[1]
    return h == make_pw_hash(name, pw, salt)

SECRET = "apple"

def hash_str(msg):
    return hmac.new(SECRET, msg).hexdigest()

def make_secure_val(msg):
    return "%s-%s" % (msg, hash_str(msg))

def check_secure_val(h):
    msg = h.split('-')[0]
    if h == make_secure_val(msg):
        return msg