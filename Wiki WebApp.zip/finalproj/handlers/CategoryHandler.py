import os
import jinja2
import webapp2

from Handler import Handler
from google.appengine.ext import db
from DB import Post

class CategoryHandler(Handler):

    def extractCategory(self):
        url = self.request.url
        catg = url[url.index('_') + 1 : len(url) - 1]
        return catg

    def run_query(self, catg):
        query = db.GqlQuery("SELECT * FROM Post WHERE categories=:1 limit 10", str(catg))
        return list(query)

    def render_page(self, query = list(), title = "", nothing = ""):
        if (len(query) == 0):
            nothing = "There is nothing here!"
        if (self.request.cookies.get('mycookie') != None):
            self.render('wikictgpage.html', query = query, title = title,
                         nothing = nothing)
        else:
            self.render('ctgpage.html', query = query, title = title,
                         nothing = nothing)

    def get(self):
        ctg = self.extractCategory()
        q = self.run_query(ctg)
        self.render_page(query = q, title = ctg)

    def post(self):
        self.search_text = self.request.get('search').lower()
        catg = self.extractCategory()
        self.query = db.GqlQuery("SELECT * FROM Post WHERE categories=:1", str(catg))
        if (self.search_text != ""):
            query = list()
            for q in self.query:
                if (self.search_text in (q.subject).lower()):
                    query.append(q)
            self.render_page(query)
        else:
            query = self.run_query()
            self.render_page(query, self.extractCategory())