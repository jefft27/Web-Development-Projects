import os
import re
import jinja2
import webapp2
from Handler import Handler
from DB import Users

class LoginHandler(Handler):

    def render_page(self, un = "", pw = "", err = ""):
        self.render('login.html', un = un, pw = pw, err = err)

    def get(self):
        self.render_page()

    def post(self):
        self.un = self.request.get('un')
        self.pw = self.request.get('pw')
        user = Users.by_name(self.un)

        if (user):
            phash = user.password_hash
            valid_passhash = self.checkPHash(phash, self.pw)
            if (valid_passhash):
                self.set_secure_cookie(self.un)
                self.redirect("/wiki?")
            else:
                self.err = "Invalid login"
                self.render_page(self.un, self.pw, self.err)
        else:
            self.err = "Invalid login"
            self.render_page(self.un, self.pw, self.err)
