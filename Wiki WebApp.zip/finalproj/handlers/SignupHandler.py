import os
import jinja2
import webapp2
from bcrypt_master import bcrypt

from Handler import Handler
from DB import Users
from miscFunctions import valid_name, valid_password

class SignupHandler(Handler):

    def render_signup(self, fn = "", ln = "",
                      un = "", pw = "", err = ""):

        self.render("signup.html", fn = fn, ln = ln, un = un,
                     pw = pw, err = err)

    def get(self):
        self.render_signup()

    def post(self):
        self.fn = self.request.get('fn')
        self.ln = self.request.get('ln')
        self.un = self.request.get('un')
        self.pw = self.request.get('pw')
        self.err = self.request.get('err')

        user_exists = Users.by_name(self.un)
        if (user_exists != None):
           self.err = "Pick a different username!"
           self.un = ""
           self.pw = ""

        if not (valid_name(self.fn) and valid_name(self.ln) and valid_name(self.un)):
            self.err += "Make sure your first, last, and user name don't have spaces"
 
        if (user_exists != None):
            self.err = "Username already exists!" 
        
        if (self.err == ""):
            self.pw = self.hashpw(self.pw)
            user_identity = Users.register(self.fn, self.ln, self.un, self.pw)
            user_identity.put()
            self.set_secure_cookie(self.un)
            self.redirect('/wiki')
        else:
            self.render_signup(self.fn, self.ln, self.un, self.pw, self.err)