import os
import re
import jinja2
import webapp2
import time
import datetime
from WikiHandler import WikiHandler
from google.appengine.ext import db
from DB import blog_key

class EditPostHandler(WikiHandler):
    def render_page(self, title = "", content = "", error = ""):
        return self.render('editpost.html', title = title,
                           content = content, error = error)

    def get(self, id):
        key = db.Key.from_path('Post', int(id), parent = blog_key())
        post = db.get(key)

        if not post:
            self.error(404)
        else:
            self.render('editpost.html', post = post)

    def post(self, id):
        key = db.Key.from_path('Post', int(id), parent = blog_key())
        post = db.get(key)
        self.content = self.request.get('content')
        post.content = self.content
        post.edited = datetime.datetime.now()
        post.creator = self.request.cookies.get('mycookie')
        post.put()
        time.sleep(.1)
        self.run_query(True)
        self.redirect('/wiki')


