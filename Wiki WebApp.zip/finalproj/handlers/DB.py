from google.appengine.ext import db
from google.appengine.api import memcache


#### This is for the user's information ####
def user_key(group = 'default'):
    return db.Key.from_path('users', group)

class Users(db.Model):

    firstname = db.StringProperty(required = True)
    lastname = db.StringProperty(required = True)
    username = db.StringProperty(required = True)
    password_hash = db.StringProperty(required = True)

    @classmethod 
    def by_name(cls, name):
        u = Users.all().filter('username = ', name).get()
        return u

    @classmethod
    def register(cls, fn, ln, un, pw):
        #pw_hash = make_pw_hash(name, pw)
        return Users(parent = user_key(),
        	        firstname = fn,
        	        lastname = ln,
        	        username = un,
        	        password_hash = pw)

#### This is to capture the post information ####
def blog_key(name = 'default'):
    return db.Key.from_path('blogs', name)

class Post(db.Model):

    subject = db.StringProperty(required = True)
    content = db.TextProperty(required = True)
    categories = db.StringProperty(required = True)
    created = db.DateTimeProperty(auto_now_add = True)
    edited = db.DateTimeProperty(auto_now_add = True)
    creator = db.StringProperty(required = True)
    
    @classmethod
    def create_post(cls, sbj, cnt, ctg, crtr):
        return Post(parent = blog_key(),
                    subject = sbj,
                    content = cnt,
                    categories = ctg,
                    creator = crtr)