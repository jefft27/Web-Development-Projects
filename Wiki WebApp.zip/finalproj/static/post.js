
function displayFormatBox() {
	var box = document.getElementById('tool_kit').style;
	if (box.display == "none") {
	   box.display = "inline-block";
	} else {
		box.display = "none";
	}
}

function highlight(elem) {
	elem.style.cursor = 'pointer'
	elem.style.boxShadow = "1px 1px 1px #888888";
}

function disappear(elem) {
	elem.style.boxShadow = "none";
}