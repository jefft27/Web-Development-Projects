function checkStrength(elem) {
    var pw = passwordStrength(elem.value, "");
    var meter = document.getElementById("meter");
    if (pw == "Weak"){
        meter.style.color = "red";
    } else if (pw == "Good") {
        meter.style.color = "orange";
    } else if (pw == "Strong") {
        meter.style.color = "green";
    }
    meter.innerHTML = pw;
    meter.value = meter.style.color;
}

function appear(){
    if (document.getElementById("pw").innerHTML == "") {
        document.getElementById("meter").innerHTML = "";
    }
}