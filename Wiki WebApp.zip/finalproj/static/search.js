function display(elem) {
    if (elem.value == "") {
        elem.value = "Search Wiki";
    }
}

function whiteOut(elem) {
    elem.value = "";
}

function shortenText(){
	var anchors = document.getElementsByTagName("a");
	for (var idx = 0; idx < anchors.length; idx += 1) {
		if (anchors[idx].id == "links") {
            if (anchors[idx].innerHTML.length > 30) {
                anchors[idx].innerHTML = anchors[idx].innerHTML.substring(0, 31)
                                         + "...";
            }
		}
	}
}