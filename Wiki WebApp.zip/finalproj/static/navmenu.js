$(document).ready(function(){

$("#dropdown, li").on("mouseenter", function(e){
  e.preventDefault();
  $(this).addClass("open");
  $(this).children("ul").slideDown("fast");
});

$("#dropdown").mouseleave(function(e){
	 console.log("in mouseleave!");
	 e.preventDefault();
    $(this).removeClass("open");
    $(this).children("ul").slideUp("fast");
});

});