/**
Variables.
 */
var expr = "";
var operators = ['%','/','x', '*','-','+', 'mod'];
var functions = ['sin', 'ln', 'cos', 'log', 'tan',
			     'sqrt', 'isin', 'icos', 'itan', 'x!', 'EXP'];
var trig_func = ['sin','cos','tan','isin','icos','itan'];
var inverse = false;
var option = false; // initially set to radians.
var trig = false;
var closedParen = false;
var eval_expr = "";

/**
Changes color of the header text.
 */
function changeColor(id) {
	color = id.innerHTML.trim();
	if (color == "Default") {
		color = "#666699";
	}
	header = document.getElementById("header").style.color = color;
}
 
/** When "Inv" button is clicked, then the trig
	buttons are changed into their inverse forms.
*/
function chngeToInverse(id) {
	if (!inverse) {
		document.getElementById("sin").value = "isin";
		document.getElementById("sin").id = "isin";
		document.getElementById("cos").value = "icos";
		document.getElementById("cos").id = "icos";
		document.getElementById("tan").value = "itan";
		document.getElementById("tan").id = "itan";
		inverse = true;
	} else {
		document.getElementById("isin").value = "sin";
		document.getElementById("isin").id = "sin";
		document.getElementById("icos").value = "cos";
		document.getElementById("icos").id = "cos";
		document.getElementById("itan").value = "tan";
		document.getElementById("itan").id = "tan";
		inverse = false;
	}
}

/** 
	Creates an expression based upon what numbers of functions the user clicks.
*/
function record(id) {
	if (expr.length == 0) {
		if (operators.indexOf(id.value) >= 0) {
			document.getElementById("numbers").value = "Error";
		}
	}
	if ((document.getElementById("numbers").value == "Error" 
		&& id.value == "AC") || id.value == "AC") {
		expr = "";
		eval_expr = "";
		document.getElementById("numbers").value = 0;
	} else {
		if (id.value != "=") {
			console.log("expr at top is: " + expr);
			if (id.value == "Rad" || id.value == "Deg") {
				return;
			} 
			else if (id.value == "Ans") {
				console.log("in Ans: " + expr);
				var x = combineTerms(expr, true);
				expr = expr + " " + x;
				eval_expr = "";
			} else if (operators.indexOf(id.value) < 0) {
				if (id.value == '(' || id.value == ')') {
					expr = expr + " " + id.value + " ";
				} else 
					expr += id.value;
			} else {
				expr = expr + " " + id.value + " ";
			}
			document.getElementById("numbers").value = expr;
		} else {
			if (!validate_string(expr) || (expr.length == 3 
				&& operators.indexOf(expr[1]) >= 0)) {
				document.getElementById("numbers").value = "Error";
			}
			document.getElementById("numbers").value = combineTerms(expr, false);
			expr = document.getElementById("numbers").value;
			eval_expr = document.getElementById("numbers").value;
		}
	}
}

/** 
Returns the value of the expression.
*/
function combineTerms(expr, pressAns) {
	var arr = expr.trim().split(/\s+/);
	eval_expr = "";
	for (var i = 0; i < arr.length; i += 1) {
		if (functions.indexOf(arr[i]) >= 0) {
			if (trig_func.indexOf(arr[i]) >= 0) {
				trig = true;
			}
			arr[i] = assign_function(arr[i]);
		} else {
			arr[i] = assign(arr[i]);
		}
		eval_expr += arr[i];
		
		if (closedParen && arr[i] == ")") {
			eval_expr += ")";
			closedParen = false;
		}
		if (trig) {
			var attach = ""
			if (option) {
				attach = "(toDegree";
			} else {
				attach = "(toRadians";
			}
			trig = false;
			closedParen = true;
			eval_expr += attach;
		}
	} // end of for loop.
	
	if (pressAns) {
		var len = eval_expr.length - 1;
		if (operators.indexOf(eval_expr[len]) >= 0) {
			eval_expr = eval_expr.substring(0, len);
		}
	}
	if (isNaN(eval(eval_expr))) {
		return "Error";
	}
	console.log("eval expr is: " + eval_expr);
	return eval(eval_expr);
}

/** Change opacity of Radian or Degree button. 
    If opacity is true, then we are in degree mode,
	and if opacity is false, then we are in radian
	mode.
*/
function changeOpacity() {
	var deg = document.getElementById("Deg");
	var rad = document.getElementById("Rad");
	
	if (!option) {
		deg.style.opacity = "0.4";
		rad.style.opacity = "1";
		option = true;
	} else {
		rad.style.opacity = "0.4";
		deg.style.opacity = "1";
		option = false;
	}
}

/** Returns the factorial of NUM.*/
function factorial(num) {
	if (num == 0 || num == 1) {
		return 1;
	}
	return num * factorial (num - 1);
}

/** Converts from Radians to Degrees.*/
function toDegree(radian) {
	return radian * (180 / Math.PI);
}

/** Convert from Degrees to Radians.*/
function toRadians(degree) {
	return degree * (Math.PI / 180);
}

/** 
Assigns each value to the function that javascript understands.
*/
function assign(element) {
	if (element == "x") {
		return "*";
	} else if (element == 'mod') {
		return '%';
	}else if (element == "%") {
		return "/100"
	}else if (element == "PI") {
		return "3.14";
	} else if (element == "e") {
		return " 2.71828183";
	} else if (element.indexOf("EXP") > 0){
		var end1 = element.indexOf("E");
		var end2 = element.indexOf("P");
		return (element.substring(0, end1) 
				* Math.pow(10, element.substring(end2 + 1))).toString();
	}
	return element;
}

/** Assigns the value of FUNC to the function 
	that javascript understands. 
*/
function assign_function(func) {
	if(func == "sin"){
		return "Math.sin";
	} else if (func == "cos") {
		return "Math.cos";
	} else if (func == "tan") {
		return "Math.tan";
	} else if (func == "isin") {
		return "Math.asin";
	} else if (func == "icos") {
		return "Math.acos";
	} else if (func == "itan") {
		return "Math.atan";
	} else if (func == "sqrt") {
		return "Math.sqrt";
	} else if (func == "x!") {
		return "factorial";
	} else if (func == "log") {// fix this.
		return "Math.log";
	} else if (func == "ln") {
		return "Math.log";
	} else if (func == "pow") {
		return "Math.pow";
	}
	return func;
}

/** 
	Returns either true or false depending on whether
	there are any illegal operations in the EXPR.
*/
function validate_string(expr) {
	var arr = expr.trim().split(/\s+/); // use this to strip whitespace.
	var flag = false;
	for (var i = 0; i < arr.length; i += 1) {
		if (operators.indexOf(arr[i]) >= 0 && !flag) {
			flag = true;
		} else if (flag && operators.indexOf(arr[i]) >= 0) {
			return false;
		} else {
			flag = false;
		}
	}
	if (!validate_parens(arr)) {
		return false;
	}
	return true;
}

/**
Validates to make sure there are no missing 
or illegal parentheses such as empty sets.
 */
function validate_parens(arr) {
	var count = 0;
	for (var i = 0; i < arr.length; i += 1) {
		if (arr[i] == '(' && arr[i + 1] == ')') {
			return false;
		} else if (arr[i] == '(') {
			count += 1;
		} else if (arr[i] == ')') {
			count -= 1;
		}
	}
	if (count != 0) {
		return false;
	}
	return true;
}
